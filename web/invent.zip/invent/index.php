<?php
header('Location: invview.php?firm=&dates=&names=&mx=');
exit;
?>